from math import ceil, floor, trunc


import math as mt

idade = -5
peso = 2.75

print("Resultado: ", idade*ceil(peso) )
print(round(peso))
print(mt.ceil(peso))
print(mt.trunc(peso))
print(mt.floor(peso))


# print(type(peso))

if 0 < idade:
    print("Valor verdadeiro")
elif idade > 2:
        print("Valor falso")
else:
    print("Não imprime nada")    

if idade %2==0:
    print("Valor Par")
else:
    print("Valor Ímpar")    