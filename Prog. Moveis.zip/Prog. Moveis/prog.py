# a = int(input("Informe um número inteiro: "))
# b = int(input("Informe um número inteiro: "))
# c = float(input("Informe um número decilmal: "))

# resultadoUm = (a*2)+(b/2)
# resultadoDois = (3*a)+c
# resultadoTres = c**3

# print(resultadoUm)
# print(resultadoDois)
# print(resultadoTres)

##Lista

li = [1, 2, 3, "a", "b"]
print(li[1]) 
print(li[-1]) ##Usando negativo, corre a lista de tras para frente 
print(li[1:4]) ##Mostra todos entre os selecionados
li.append("cachorro") ##add no final da lista
li.insert(0,"Mosca") ##Insere no local escolhido
print(len(li)) ##Msotra o tamanho da lista
li.reverse() ##Inverte a lista
print(li)
print("")

##Tuplas    Uma vez criada não pode ser modificada

tu = (1,2, "ab",2.4)
print(tu)
print("")

##dicionarios

dic ={1:"Altair",2:"Kennes",3:"Rodrigo"}
print(dic.keys()) ##Ver todas as chaves
print(dic.values()) ##Ver todos os valores
dic[4]="Teste"
print(dic)
print("")

#Repetidores

for i in range(0,10,3):   ## Começa | Ate onde vai | De quanto em quanto vai rodar
    print (i)
print("")
# for i in li:
#     print(li)

for i, valor in enumerate(li):
    print(i, valor)

print("")


x = 4
while x <10:
    print(x)
    x+=1

file = open ("test.txt","w")
file.write("Teste de gravação")
file.writelines([" Teste de gravação1","\nTeste de gravação 3"]) ## COloca todo em uma so
file.close()

file = open("test.txt","r")
print(file.read())
for dados in file:
    print(dados)