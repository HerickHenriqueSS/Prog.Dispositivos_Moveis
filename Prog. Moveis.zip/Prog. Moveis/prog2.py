li =[]

i = 0
while i <10:
    valores = input("Informe um Valor")
    li.append(valores)
    i+=1
print(li)

file = open ("ListaAdicionada","w")
file.writelines([li])
file.close()

